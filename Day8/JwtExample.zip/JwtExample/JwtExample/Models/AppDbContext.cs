﻿using Microsoft.EntityFrameworkCore;
using static JwtExample.Models.Users;

namespace JwtExample.Models
{
    public class AppDbContext : DbContext
    {
        public DbSet<User> Users { get; set; }

        public AppDbContext(DbContextOptions<AppDbContext> options) : base(options) { }
    }
}
